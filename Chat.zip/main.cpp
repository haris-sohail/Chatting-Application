#include <iostream>

// libraries for fork()

#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<string.h>


using namespace std;

int main()
{	
	int status;

    string username;

    cout << "Hello. Please enter your username: ";
    getline(cin, username); 

    cout << endl;
	
	if (fork() == 0) // child process
	{      
        int choice = 0;
        while(1)
        {
            cout << endl;
            cout << "========================" << endl;
            cout << "1: Write into memory" << endl;
            cout << "2: Read from memory" << endl;
            cout << "0: Exit" << endl;
            cout << "========================" << endl;

            cout << "Enter your choice: ";

            cin >> choice;

            if(choice == 1) // Write
            {

                 // --- writing ---

                //  In this code, synchronization can occur when multiple instances of the program access the shared memory concurrently during the write operation.
                //  Since writing to shared memory is a critical section, the process should acquire a lock or semaphore to ensure that only one process can access the shared memory at a time.
            

                // To avoid this issue, one approach would be to use a semaphore or a mutex to enforce mutual exclusion during the write operation.
                // When a process wants to write to the shared memory, it should first acquire the lock using the semaphore or mutex. 
                // After the write operation is completed, the lock should be released to allow other processes to access the shared memory. 
                // This will ensure that only one process writes to the shared memory at a time, preventing data corruption and ensuring consistency.

                if(fork() == 0)
                {
                    cout << execl("/home/haris/Haris'/Assignments/OS-A1/writeObj", "writeObj", username.c_str(), NULL) << endl; 

                    exit(0);
                }
                else 
                {
                    wait(NULL);
                }            

            }

            else if (choice == 2)
            {
                // --- reading ---

                // Synchronization issues can also occur during the read operation if the shared memory is being modified
                // or written to by another process while a read operation is in progress. In this code, there is no synchronization
                // mechanism implemented for the read operation as well.

                // To avoid this issue, the processes should use locking or synchronization mechanisms to ensure mutual exclusion during both read and write operations. 
                // One approach is to use a read-write lock, where multiple processes can simultaneously read from the shared memory, but only one process can write to it at a time. 
                // Alternatively, the processes can use semaphores or mutexes to acquire and release locks during both read and write operations, ensuring that only one process is accessing the shared memory at a time. 
                // This will prevent synchronization issues and ensure the consistency of the shared memory.

                if(fork() == 0)
                {
                    // send the username as an argument for verification

                    execl("/home/haris/Haris'/Assignments/OS-A1/readObj", "readObj", username.c_str(), NULL);

                    exit(0);
                }
                else 
                {
                    wait(NULL);
                } 
            }

            else if(choice == 0)
            {
               exit(0);
            }

            else
            {
               cout << "Invalid Choice" << endl << endl;
            }
        }
        
	}	
	else // parent process
	{
		wait(NULL);
	}
}	