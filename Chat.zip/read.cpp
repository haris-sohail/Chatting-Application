#include<iostream>
#include<stdlib.h>
#include<unistd.h>
#include<sys/shm.h>
#include<string.h>

using namespace std;

int main(int noOfArgs, char* args[])
{
    void *shared_memory;
    char buff[100];
    char message[100];
    int shmid;

    // getting shared memory
    shmid = shmget((key_t)1100, 1024, 0666 | IPC_CREAT); //creates shared memory segment

    // attaching to shared mem
    shared_memory = shmat(shmid, NULL, 0); //process attached to shared memory segment

    cout << "Enter some data to write to shared memory: ";

    // read the message from the sender
    cin.getline(buff, 100);

    // add the username in the message and then a comma

    strcpy(message, args[1]);

    strcat(message, ",");

    // now combine the user entered message in the message variable

    strcat(message, buff);

    strcpy((char *)shared_memory,message); //data written to shared memory

    // outputting the data written
    //cout << "You wrote : " << (char*) shared_memory << endl;
}

