#include<iostream>
#include<stdlib.h>
#include<unistd.h>
#include<sys/shm.h>
#include<string.h>
#include<string>

using namespace std;

int main(int noOfArgs, char* args[])
{
    void *shared_memory;
    char buff[100];
    int shmid;

    // getting the shared memory which has been used before for writing
    shmid=shmget((key_t)1100, 1024, 0666);
    
    //printf("Key of shared memory is %d\n",shmid);

    // attaching to the shared memory
    shared_memory=shmat(shmid,NULL,0); //process attached to shared memory segment
    
    //printf("Process attached at %p\n",shared_memory);

    char username_read[20];

    // read the username from the message

    int i;
    
    for(i = 0; ((char*) shared_memory)[i] != ','; i++)
    {
        username_read[i] = ((char*) shared_memory)[i];
    }

    username_read[i] = '\0';

    i++;

    //cout << endl << username_read << endl;
    
    if(strcmp(username_read, args[1]) == 0) // the sender is the same as the receiver, therefore we don't have to print the message
    {
        cout << endl << "No unread messages" << endl;
    }

    else // Printing the shared memory data
    {
        cout << "The message is from: " << username_read << endl;
        for(; ((char*)shared_memory)[i] != '\0'; i++)
        {
            cout << ((char*) shared_memory)[i];
        }
    }

    cout << endl;
}